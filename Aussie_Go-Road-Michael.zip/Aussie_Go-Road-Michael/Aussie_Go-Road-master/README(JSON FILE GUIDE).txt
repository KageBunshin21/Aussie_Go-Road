Author: Michael Ibesa

JSON file is structured by having each tourist spot referred to ID which 1, 2, 3 ...

and then the letters after the ID represents the category:
B = tourist spot name
C = state
D = tourist spot rules and regulations links
E = state laws/by-laws links
F = Facts 
G = Tips 
H = Tips links

to access this refer to variable savedInfo (located in main.lua) 

the syntax looks like this: savedInfo["ID"]["letter"]

*NOTE: do not forget the quotation marks "" and the text I used for the scenes(tips, facts, laws & regulations) are just using savedInfo["ID"]["letter"] since I do not have the search function yet

The scenes I've added to this file are:
- tipsSuggestionsView
- factsView
- lawsRegulationsView
- planRouteScene

