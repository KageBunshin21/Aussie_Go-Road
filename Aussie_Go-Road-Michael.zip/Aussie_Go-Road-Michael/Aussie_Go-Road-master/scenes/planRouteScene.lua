-----------------------------------------------------------------------------------------
--
-- 	planRouteScene.lua
--
-- 	This is the scene in which the plan my route is presented along 
-- 	it contains the buttons that links to pages such as: 
-- 	*tips and suggestions, facts, laws/by-laws and rules/regulations
--
--  Author: Michael Ibesa and Ricardo Felix Costa
--  Date: October 3, 2018 
-----------------------------------------------------------------------------------------

local composer = require( "composer" )

local scene = composer.newScene()

-- -----------------------------------------------------------------------------------
-- Code outside of the scene event functions below will only be executed ONCE unless
-- the scene is removed entirely (not recycled) via "composer.removeScene()"
-- -----------------------------------------------------------------------------------

-- -----------------------------------------------------------------------------------
-- user interface stuff
-- -----------------------------------------------------------------------------------

--local widget = require( "widget" )

local X = display.contentCenterX
local Y = display.contentCenterY

-- font settings
titleFontStyle = "Impact"
subTitleFontStyle = "Calibri"
normalfontStyle = "Arial"
buttonFontStyle = "Lucida Sans"
titleFontSize = 40
subTitleFontSize = 30
normalFontSize = 20
align = "center"

-- -----------------------------------------------------------------------------------
-- Scene event functions
-- -----------------------------------------------------------------------------------

-- function to go to Tips Page
local function goToTips()
	composer.gotoScene( "scenes.tipsSuggestionsView", "crossFade", 1000 )    
    return true
end

local function goToFacts()
	composer.gotoScene( "scenes.factsView", "crossFade", 1000 )    
    return true
end

local function goToLawsRegulations()
	composer.gotoScene( "scenes.lawsRegulationsView", "crossFade", 1000 )    
    return true
end

local function gotoMenu()
    composer.gotoScene( "scenes.mainMenu" )
end
--[[local function gotoReportIncidents()
    composer.gotoScene( "scenes.reportIncidents" )
end

local function gotoPlanMyRoute()
    composer.gotoScene( "scenes.planMyRoute" )
end

local function gotoAboriginalPermissions()
    composer.gotoScene( "scenes.aboriginalPermissions" )
end

local function gotoAbout()
    composer.gotoScene( "scenes.about" )
end
]]--
-- function to go back to mainMenu


-- -----------------------------------------------------------------------------------
-- Scene event functions
-- -----------------------------------------------------------------------------------

-- create()
function scene:create( event )

    local sceneGroup = self.view
    -- Code here runs when the scene is first created but has not yet appeared on screen
	
	-- Display title "Plan My Route"
	local title = display.newText("Plan My Route", display.contentCenterX, 10, titleFontStyle, titleFontSize) 
	sceneGroup:insert(title)
	
	-- Display sub title which is the name of the tourist spot
	local subTitle = display.newText(savedInfo["1"]["B"], display.contentCenterX, 50, subTitleFontStyle, subTitleFontSize) 
	sceneGroup:insert(subTitle)
	
	-- a button that links to tips and suggestion
	local tipsButton = display.newImageRect( sceneGroup, "/assets/quickTips.png", 320, 70 )
    tipsButton.x = display.contentCenterX+3
    tipsButton.y = 125
	
	-- a button that links to facts page
	local factsButton = display.newImageRect( sceneGroup, "/assets/factsIcon.png", 320, 70 )
    factsButton.x = display.contentCenterX+3
    factsButton.y = 230
	
	-- a button that links to Laws/By-laws
	local lawsButton = display.newImageRect( sceneGroup, "/assets/lawsIcon.png", 320, 70 )
    lawsButton.x = display.contentCenterX+3
    lawsButton.y = 335

	-- a button that links back to the welcome screen
	local backButton = display.newImageRect( sceneGroup, "/assets/back.png", 150, 60 )
    backButton.x = display.contentCenterX+3
    backButton.y = 480
	
	-- event listeners for the buttons
	tipsButton:addEventListener( "tap", goToTips)
	factsButton:addEventListener( "tap", goToFacts)
	lawsButton:addEventListener( "tap", goToLawsRegulations)
	backButton:addEventListener( "tap", gotoMenu)
	
    --[[factsButton:addEventListener( "tap", gotoPlanMyRoute)
    lawsButton:addEventListener( "tap", gotoAboriginalPermissions)
    rulesButton:addEventListener( "tap", gotoAbout)
    ]]--
end
	
-- show()
function scene:show( event )

    local sceneGroup = self.view
    local phase = event.phase

    if ( phase == "will" ) then
        -- Code here runs when the scene is still off screen (but is about to come on screen)

    elseif ( phase == "did" ) then
        -- Code here runs when the scene is entirely on screen

    end
end


-- hide()
function scene:hide( event )

    local sceneGroup = self.view
    local phase = event.phase

    if ( phase == "will" ) then
        -- Code here runs when the scene is on screen (but is about to go off screen)

    elseif ( phase == "did" ) then
        -- Code here runs immediately after the scene goes entirely off screen

    end
end

-- destroy()
function scene:destroy( event )

    local sceneGroup = self.view
    -- Code here runs prior to the removal of scene's view

	-- clean up audio stuff
--	audio.stop()

--	for s,v in pairs( soundTable ) do
--		audio.dispose( soundTable[s] )
--		soundTable[s] = nil
--	end
end


-- -----------------------------------------------------------------------------------
-- Scene event function listeners
-- -----------------------------------------------------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )
-- -----------------------------------------------------------------------------------

return scene